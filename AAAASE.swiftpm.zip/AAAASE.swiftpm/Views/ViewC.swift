import SwiftUI

struct ViewC: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let images = [
        "keynote1", "keynote2", "keynote3", "keynote4", "keynote5", "keynote6", "keynote7"
    ] + [
        "shortcuts", "shortcut1", "shortcut2", "shortcut3", "shortcut4", "shortcut5", "shortcut6", "shortcut7"
    ]
    
    @State private var imageTexts = [
        "1. Här kan du ladda ner Idékompassen för att välja din bästa idé. Du kan också ladda ner AppGPT, en chatbot som hjälper dig att utveckla din appidé, en One Pager-presentation för att presentera din appidé och en analys av din favoritapp.",
        "2. App-prototyp för iPad i Keynote\nI denna Keynote-fil får du ett anpassat tema för att utveckla prototypen av din app för iPad. Genom att klicka på + för att lägga till en ny bild kan du välja mellan olika layoutalternativ för att bäst visa upp dina idéer.",
        "3. App-prototyp för iPhone i Keynote\nI denna Keynote-fil får du ett anpassat tema för att utveckla prototypen av din app för iPhone. Genom att klicka på + för att lägga till en ny bild kan du välja mellan flera layoutalternativ för att effektivt kommunicera dina idéer.",
        "4. App-prototyp för MacBook i Keynote\nI denna Keynote-fil får du ett speciellt tema för att skapa en prototyp av din app för MacBook. Genom att trycka på + för att lägga till en ny bild kan du välja mellan flera layoutalternativ för att tydligt presentera dina idéer.",
        "5. App-prototyp för Apple Watch i Keynote\nI denna Keynote-fil får du ett unikt tema för att designa en prototyp av din app för Apple Watch. Genom att trycka på + för att lägga till en ny bild kan du välja mellan flera layoutalternativ för att effektivt kommunicera dina idéer.",
        "6. Undervisningsmaterial\nI undervisningsmaterialet får du resurser som hjälper dig, som lärare, att säkert starta projektet 'En App om Appar'. Du kan ladda ner en Keynote-bok som vägleder dig genom alla steg från idé till app-prototyp.",
        "7. Undervisningsmaterial i Swift\nDessutom kan du ladda ner en Keynote-bok som fokuserar på hur man börjar programmera i Swift och stöder apparna i fliken 'App' under dina lektioner.",
        "Skapa en genväg till din app",
        "1. Öppna appen Genvägar på din iPad.",
        "2. Tryck på \"+\" för att skapa en ny genväg till din hemskärm.",
        "3. Sök efter Keynote i sökfältet. Välj nu snabbkommandot 'Spela upp presentation i åskådarläge'.",
        "4. Tryck på Keynote-presentationen för att välja den fil som ska öppnas när genvägen trycks på.",
        "5. Tryck nu på pilen och byt namn på genvägen genom att trycka på 'Byt namn'. Välj en ikon för genvägen och tryck sedan på 'Lägg till på hemskärmen'.",
        "6. Tryck på 'Lägg till' för att lägga till genvägen på hemskärmen.",
        "7. Nu har du skapat en genväg på din hemskärm."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack {
                    Text("Skapa en prototyp med sidbytarknappar")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("På denna sida kan du ladda ner material för elever, analysera dina appidéer och välja den bästa. Du kan också ladda ner material för att arbeta med din favoritapp, skapa en One Pager-presentation och ladda ner AppGPT, en chatbot som hjälper dig att reflektera över din appidé. Dessutom kan du ladda ner app-prototyper i Keynote, designade för iPad, iPhone, MacBook och Apple Watch. Som lärare kan du också ladda ner undervisningsmaterial, inklusive resurser för att underlätta projektet och material som fokuserar på programmering i Swift.")
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Material för elever", description: "Klicka här för att ladda ner Idékompassen, AppGPT, Min favoritapp och One Pager-presentationen.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        contentBox(title: "App-prototyp för iPad", description: "Klicka här för att ladda ner Keynote-filen för iPad-prototypen. Utveckla dina idéer utan problem.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20iPad.key")
                        
                        contentBox(title: "App-prototyp för iPhone", description: "Klicka här för att ladda ner Keynote-filen för iPhone-prototypen. Ge liv åt dina appidéer.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20iPhone.key.zip")
                        
                        contentBox(title: "App-prototyp för Mac", description: "Klicka här för att ladda ner Keynote-filen för Mac-prototypen. Designa och förbättra dina koncept.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20MacBook.key.zip")
                        
                        contentBox(title: "App-prototyp för Apple Watch", description: "Klicka här för att ladda ner Keynote-filen för Apple Watch-prototypen. Innovera och visualisera din app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20Apple%20Watch.key")
                        
                        contentBox(title: "Undervisningsmaterial", description: "En komplett guide för 'En App om Appar'. Ladda ner Keynote-böcker som hjälper dig att komma igång och undervisa i programmering i Swift.", linkURL: "https://app.box.com/s/b6a1m1jguxyx5fp6a476tbo0tfcn6gjf")
                        
                        contentBox(title: "Undervisningsmaterial i Swift", description: "Du kan också ladda ner en Keynote-bok som fokuserar på hur man börjar programmera i Swift och stöder apparna i fliken 'App' under undervisningen.", linkURL: "https://app.box.com/s/76jghz4hifyu5e4uh8egap5jk21ocwj5")
                    }
                
                    .padding()
                }
            }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation {
                            showPopup.toggle()
                        }
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            if showPopup {
                PopupView3(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let index = fullscreenImageIndex {
                FullscreenImageView2(images: images, descriptions: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black)
            
            Divider()
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black)
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }


struct ViewCDrawingLine {
    var points: [CGPoint]
    var color: Color
}

struct FullscreenImageView2: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.black, lineWidth: 1)
                                            )
                                    )
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                Spacer()
            }
        }
    }
}
struct PopupView3: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @State private var currentPage: Int = 0
    @State private var isFullScreen: Bool = false
    @Binding var fullscreenImageIndex: Int?
    var body: some View {
        VStack(spacing: 20) {
            Text("Vad är en App om Appar?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        ZStack {
                            Image(images[index])
                                .resizable()
                                .aspectRatio(contentMode: isFullScreen ? .fit : .fill)
                                .frame(width: isFullScreen ? UIScreen.main.bounds.width : 400, height: isFullScreen ? UIScreen.main.bounds.height : 300)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = index
                                    }
                                }
                            
                            if isFullScreen {
                                VStack {
                                    Spacer()
                                    Text(imageTexts[index])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                        .padding()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .transition(.opacity)
                            }
                        }
                        
                        if !isFullScreen {
                            ScrollView {
                                Text(imageTexts[index])
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 100)
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                withAnimation {
                    showPopup = false
                }
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
} 
    struct ViewC_Previews: PreviewProvider {
        static var previews: some View {
            ViewC()
        }
    }
