import SwiftUI

struct ViewD: View {
    
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
               
                VStack {
                    Text("Appar du kan använda som byggstenar och inspiration")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("På denna sida ska du beskriva vad din app bör innehålla, hur den bör se ut och varför. Detta arbete ska sammanfattas i ett dokument på en tavla i Freeform. Vi har skapat en mall åt dig. Du kan ladda ner den genom att klicka på Freeform-ikonen nedan. När dokumentet har laddats ner måste du duplicera det. Få mer information genom informationsknappen på denna sida.")
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                    
                    ScrollView {
                        LazyVGrid(columns: columns, spacing: 20) {
                            contentBox(title: "Börja med kod", description: "En bra utgångspunkt för din resa inom programmering.", linkURL: "")
                            
                            contentBox(title: "Om mig", description: "Skapa ett projekt om dig själv och lär dig att programmera medan du bygger din första app.", linkURL: "")
                            
                            contentBox(title: "Skapa en navigeringsfält", description: "Lär dig att skapa en meny med tre eller fler knappar. Denna app ingår i ditt abonnemang på 'En App om Appar' på huvudsidan i Swift. Skrolla ner och hitta navigeringsfälts-appen.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                            
                            contentBox(title: "Stack Views", description: "Lär dig att placera objekt horisontellt, vertikalt och längs Z-axeln eller kombinera de olika alternativen. Denna app ingår i ditt abonnemang på 'En App om Appar' på huvudsidan i Swift. Skrolla ner och hitta Stack Views-appen.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                            
                            contentBox(title: "Lägg till innehåll", description: "Lär dig att lägga till bilder, videor och länkar i din app. Denna app ingår i ditt abonnemang på 'En App om Appar' på huvudsidan i Swift. Skrolla ner och hitta appen för att lägga till innehåll.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                            
                            contentBox(title: "Element för att komma igång", description: "Detta är en app med flera idéer, som GPS-kartor från Apple Maps och olika typer av knappar som kan göra din app unik. Denna app ingår i ditt abonnemang på 'En App om Appar' på huvudsidan i Swift. Skrolla ner och hitta appen med start-elementen.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                        
                        }
                    }
                    }
                    .padding()
                }
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black) 
            
            Divider()  
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black) 
            
            Text("Länk")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)  
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }


struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}

