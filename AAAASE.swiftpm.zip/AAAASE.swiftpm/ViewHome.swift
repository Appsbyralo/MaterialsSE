import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. En App om Appar\nDetta är en designprocess som tar dig från idéutveckling till skapandet av app-prototyper och slutligen till en färdig app. Den här informationsknappen ger dig en översikt över appens innehåll.",
        "2. Rita\nI fliken Rita kan du skissa med inbyggda verktyg och förklara dina idéer, samt utveckla designen. Klicka på 'Idégenerering' för att skissa 8 appidéer, varifrån du sedan kan välja den bästa. I 'Tom', 'iPhone' och 'iPad' kan du designa layouten för din app i olika format.",
        "3. Fri form\nNär du klickar på Fri form kan du ladda ner ett tankekarta i Freeform för att koppla samman alla dina idéer. I tankekartan kan du dra olika typer av knappar, iPhone-ramar och anteckningar till ditt arbetsområde. Om du föredrar det kan du även göra en traditionell tankekarta på papper.",
        "4. Material\nI Material kan du ladda ner Keynote-mallar för att skapa prototyper av din app, vare sig det är för Apple Watch, iPhone, iPad eller MacBook. Varje Keynote-mall är unik och erbjuder olika inställningar för dina layouter. Du kan även ladda ner undervisningsmaterial för projektet och aktiviteter för studenter. Om du vill kan du även ladda ner material som specifikt lär ut programmering i Swift.",
        "5. App\nI fliken App kan du lära dig hur du kommer igång med programmering i Swift. Här kan du utforska Apples material 'Kom igång med kod' och 'Om mig'. Specifikt för 'En App om Appar' kan du ladda ner 4 appar som lär dig hur du skapar navigeringsfält (menyer), Stack Views (objektorganisering), lägger till innehåll (texter, bilder, videor och länkar) och olika användbara funktioner.",
        "6. Portfolio\nI avsnittet Portfolio kan du uppdatera och dokumentera din resa från idé, till design, feedback och prototyper, fram till den slutgiltiga appen. I portfolion kan du ladda upp foton från ditt galleri och beskriva din erfarenhet med texter. I slutet av portfolion kan du lägga till fler bild- och textfält."
    ]

    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("En App om Appar")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    Text("En App om Appar hjälper dig att gå från idéutveckling, till att rita och beskriva dessa idéer, till att skapa app-prototyper. Om du vill kan du också lära dig att programmera i Swift, så att du en dag kan publicera en riktig app på App Store. Förverkliga dina visioner och idéer! Klicka på informationsknappen för att få en översikt över de olika sektionerna i appen.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Klicka på informationsknappen för att få en översikt över de olika sektionerna i appen.")
                        .font(.system(size: 20, weight: .regular))
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                }
     
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Vad är en App om Appar?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200)  
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

