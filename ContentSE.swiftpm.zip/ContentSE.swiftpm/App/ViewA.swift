import SwiftUI

/*#-code-walkthrough(VA.1)*/
struct ViewA: View {
    var body: some View {
        /*#-code-walkthrough(VA.2)*/
       
        Image("Image1")
        /*#-code-walkthrough(VA.2)*/
    
        /*#-code-walkthrough(VA.1)*/
    }
}
struct ViewA_Previews: PreviewProvider {
    static var previews: some View {
        ViewA()
    }
}



