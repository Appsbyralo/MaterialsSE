import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        TabView {
            ViewA()
                .tabItem {
                    Image(systemName: "phone.fill")
                    Text("Lägg till foto")
                }
            ViewB()
                .tabItem {
                    Image(systemName: "eraser.fill")
                    Text("Lägg till länk")
                }
            ViewC()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("Lägg till video")
                }
            ViewD()
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Scrollvy")

                }
        }
    }
}




