import SwiftUI

struct ViewB: View {
    var body: some View {
        
        ZStack {
            /*#-code-walkthrough(4.modifier)*/
            /*#-code-walkthrough(4.1.modifier)*/
            Color(red: 090 / 255, green: 125 / 255, blue: 219 / 255)
            /*#-code-walkthrough(4.1.modifier)*/
            Image(systemName: "house.circle")
                .foregroundColor(Color.white) 
                .font(.system(size: 100.0))
            /*#-code-walkthrough(4.modifier)*/
        }
    }
}

struct ViewB_Previews: PreviewProvider {
    static var previews: some View {
        ViewB()
    }
}

